package com.example.enderpearl.data;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Per-player mode storage in players.yml. Only explicit choices are stored;
 * everyone else falls back to the configured default.
 * All access happens on the main server thread.
 */
public final class PlayerDataStore {

    private static final String ROOT = "players";

    private final File file;
    private final PearlMode defaultMode;
    private final Logger logger;
    private final Map<UUID, PearlMode> modes = new HashMap<>();

    public PlayerDataStore(File dataFolder, PearlMode defaultMode, Logger logger) {
        this.file = new File(dataFolder, "players.yml");
        this.defaultMode = defaultMode;
        this.logger = logger;
    }

    public void load() {
        if (!file.isFile()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection(ROOT);
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException e) {
                logger.warning("Skipping malformed player id in players.yml: " + key);
                continue;
            }
            PearlMode.parse(section.getString(key)).ifPresent(mode -> modes.put(id, mode));
        }
    }

    public PearlMode getMode(UUID playerId) {
        return modes.getOrDefault(playerId, defaultMode);
    }

    public PearlMode toggle(UUID playerId) {
        PearlMode next = getMode(playerId).toggled();
        modes.put(playerId, next);
        save();
        return next;
    }

    /** Writes players.yml atomically (temp file, then move) so a crash cannot leave it half-written. */
    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        modes.forEach((id, mode) -> yaml.set(ROOT + "." + id, mode.name()));
        try {
            Path target = file.toPath();
            Files.createDirectories(target.getParent());
            Path temp = target.resolveSibling(file.getName() + ".tmp");
            Files.writeString(temp, yaml.saveToString(), StandardCharsets.UTF_8);
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to save players.yml", e);
        }
    }
}
