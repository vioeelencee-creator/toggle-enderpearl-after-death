package com.example.enderpearl.data;

import java.util.Locale;
import java.util.Optional;

public enum PearlMode {
    /** Thrown pearls survive the owner's death (default). */
    PERSISTENT,
    /** Thrown pearls vanish on death, as in vanilla. */
    VANILLA;

    public PearlMode toggled() {
        return this == PERSISTENT ? VANILLA : PERSISTENT;
    }

    public static Optional<PearlMode> parse(String raw) {
        if (raw == null) {
            return Optional.empty();
        }
        try {
            return Optional.of(valueOf(raw.trim().toUpperCase(Locale.ROOT)));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }
}
