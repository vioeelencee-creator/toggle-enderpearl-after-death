package com.example.enderpearl.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Pearls removed at their owner's death, waiting for that owner to respawn (or rejoin).
 * In-memory only: pending pearls do not survive a server restart.
 */
public final class PendingPearlStore {

    private final Map<UUID, List<PearlSnapshot>> pending = new HashMap<>();

    public void add(UUID owner, Collection<PearlSnapshot> snapshots) {
        pending.computeIfAbsent(owner, id -> new ArrayList<>()).addAll(snapshots);
    }

    /** Removes and returns the owner's pending pearls; empty if there are none. */
    public List<PearlSnapshot> take(UUID owner) {
        List<PearlSnapshot> snapshots = pending.remove(owner);
        return snapshots == null ? List.of() : snapshots;
    }
}
