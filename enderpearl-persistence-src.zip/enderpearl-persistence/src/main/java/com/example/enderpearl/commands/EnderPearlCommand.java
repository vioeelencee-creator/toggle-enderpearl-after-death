package com.example.enderpearl.commands;

import com.example.enderpearl.config.Messages;
import com.example.enderpearl.data.PearlMode;
import com.example.enderpearl.data.PlayerDataStore;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Locale;

/**
 * Handles /enderpearl, /ep and /eptoggle.
 * No arguments or "toggle" flips the player's mode; "status" reports it.
 */
public final class EnderPearlCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBCOMMANDS = List.of("toggle", "status");

    private final PlayerDataStore dataStore;
    private final Messages messages;

    public EnderPearlCommand(PlayerDataStore dataStore, Messages messages) {
        this.dataStore = dataStore;
        this.messages = messages;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(messages.playerOnly());
            return true;
        }

        String sub = args.length == 0 ? "toggle" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "toggle" -> {
                PearlMode mode = dataStore.toggle(player.getUniqueId());
                player.sendMessage(messages.modeChanged(mode));
            }
            case "status" -> player.sendMessage(messages.status(dataStore.getMode(player.getUniqueId())));
            default -> player.sendMessage(messages.usage());
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) {
            return List.of();
        }
        String prefix = args[0].toLowerCase(Locale.ROOT);
        return SUBCOMMANDS.stream().filter(s -> s.startsWith(prefix)).toList();
    }
}
