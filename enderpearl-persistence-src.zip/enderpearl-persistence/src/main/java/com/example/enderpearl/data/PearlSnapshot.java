package com.example.enderpearl.data;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.EnderPearl;
import org.bukkit.util.Vector;

import java.util.UUID;

/** Position and velocity of an in-flight ender pearl, captured at its owner's death. */
public record PearlSnapshot(UUID worldId,
                            double x, double y, double z,
                            double velocityX, double velocityY, double velocityZ) {

    public static PearlSnapshot capture(EnderPearl pearl) {
        Location at = pearl.getLocation();
        Vector velocity = pearl.getVelocity();
        return new PearlSnapshot(pearl.getWorld().getUID(),
                at.getX(), at.getY(), at.getZ(),
                velocity.getX(), velocity.getY(), velocity.getZ());
    }

    /** The captured location, or {@code null} if its world is no longer loaded. */
    public Location toLocation() {
        World world = Bukkit.getWorld(worldId);
        return world == null ? null : new Location(world, x, y, z);
    }

    public Vector velocity() {
        return new Vector(velocityX, velocityY, velocityZ);
    }
}
