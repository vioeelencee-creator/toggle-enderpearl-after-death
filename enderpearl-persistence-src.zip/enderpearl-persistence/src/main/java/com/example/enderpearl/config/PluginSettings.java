package com.example.enderpearl.config;

import com.example.enderpearl.data.PearlMode;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.logging.Logger;

/** Immutable snapshot of config.yml, read once at enable time. */
public record PluginSettings(PearlMode defaultMode, Messages messages) {

    public static PluginSettings load(FileConfiguration config, Logger logger) {
        String raw = config.getString("default-mode", PearlMode.PERSISTENT.name());
        PearlMode mode = PearlMode.parse(raw).orElseGet(() -> {
            logger.warning("Invalid default-mode '" + raw + "' in config.yml; using PERSISTENT.");
            return PearlMode.PERSISTENT;
        });
        return new PluginSettings(mode, Messages.from(config));
    }
}
