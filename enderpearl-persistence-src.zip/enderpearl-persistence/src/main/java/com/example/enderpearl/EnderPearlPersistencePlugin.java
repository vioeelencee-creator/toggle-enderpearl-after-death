package com.example.enderpearl;

import com.example.enderpearl.commands.EnderPearlCommand;
import com.example.enderpearl.config.Messages;
import com.example.enderpearl.config.PluginSettings;
import com.example.enderpearl.data.PendingPearlStore;
import com.example.enderpearl.data.PlayerDataStore;
import com.example.enderpearl.listeners.PearlDeathListener;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class EnderPearlPersistencePlugin extends JavaPlugin {

    private PlayerDataStore dataStore;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        PluginSettings settings = PluginSettings.load(getConfig(), getLogger());
        Messages messages = settings.messages();

        dataStore = new PlayerDataStore(getDataFolder(), settings.defaultMode(), getLogger());
        dataStore.load();

        PluginCommand command = getCommand("enderpearl");
        if (command == null) {
            getLogger().severe("Command 'enderpearl' is not declared in paper-plugin.yml; disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        EnderPearlCommand executor = new EnderPearlCommand(dataStore, messages);
        command.setExecutor(executor);
        command.setTabCompleter(executor);

        getServer().getPluginManager().registerEvents(
                new PearlDeathListener(this, dataStore, new PendingPearlStore(), messages), this);

        getLogger().info("Enabled. Default mode: " + settings.defaultMode());
    }

    @Override
    public void onDisable() {
        if (dataStore != null) {
            dataStore.save();
        }
    }
}
