package com.example.enderpearl.config;

import com.example.enderpearl.data.PearlMode;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.configuration.file.FileConfiguration;

/** MiniMessage-formatted player feedback, loaded from the "messages" section of config.yml. */
public final class Messages {

    private static final MiniMessage MINI = MiniMessage.miniMessage();

    private final String enabled;
    private final String disabled;
    private final String statusPersistent;
    private final String statusVanilla;
    private final String restoredTemplate;
    private final String usage;
    private final String playerOnly;

    private Messages(FileConfiguration cfg) {
        this.enabled = read(cfg, "enabled",
                "<green>Enderpearl persistence is now <bold>ENABLED</bold>. Your pearls will not disappear on death!</green>");
        this.disabled = read(cfg, "disabled",
                "<yellow>Enderpearl persistence is now <bold>DISABLED</bold>. Your pearls will vanish on death, like vanilla.</yellow>");
        this.statusPersistent = read(cfg, "status-persistent",
                "<gray>Your mode: <green>PERSISTENT</green>. Thrown pearls survive death.</gray>");
        this.statusVanilla = read(cfg, "status-vanilla",
                "<gray>Your mode: <red>VANILLA</red>. Thrown pearls vanish on death.</gray>");
        this.restoredTemplate = read(cfg, "restored",
                "<aqua>Restored <count> ender pearl(s) from before your death.</aqua>");
        this.usage = read(cfg, "usage", "<gray>Usage: /enderpearl [toggle|status]</gray>");
        this.playerOnly = read(cfg, "player-only", "<red>Only players can use this command.</red>");
    }

    public static Messages from(FileConfiguration cfg) {
        return new Messages(cfg);
    }

    private static String read(FileConfiguration cfg, String key, String fallback) {
        return cfg.getString("messages." + key, fallback);
    }

    public Component modeChanged(PearlMode mode) {
        return MINI.deserialize(mode == PearlMode.PERSISTENT ? enabled : disabled);
    }

    public Component status(PearlMode mode) {
        return MINI.deserialize(mode == PearlMode.PERSISTENT ? statusPersistent : statusVanilla);
    }

    public Component restored(int count) {
        return MINI.deserialize(restoredTemplate, Placeholder.unparsed("count", String.valueOf(count)));
    }

    public Component usage() {
        return MINI.deserialize(usage);
    }

    public Component playerOnly() {
        return MINI.deserialize(playerOnly);
    }
}
