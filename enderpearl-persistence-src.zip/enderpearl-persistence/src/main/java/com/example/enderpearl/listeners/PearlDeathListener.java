package com.example.enderpearl.listeners;

import com.example.enderpearl.config.Messages;
import com.example.enderpearl.data.PearlMode;
import com.example.enderpearl.data.PearlSnapshot;
import com.example.enderpearl.data.PendingPearlStore;
import com.example.enderpearl.data.PlayerDataStore;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

/**
 * Keeps a persistent player's thrown pearls alive across death.
 *
 * Vanilla discards a thrown pearl on the first tick after its owner dies, and no
 * cancellable event covers that path. So on death we capture each in-flight pearl
 * and remove it ourselves, then respawn an identical pearl (same position, velocity,
 * and owner) once the player is alive again. The pearl resumes its flight, and its
 * landing teleports the player as usual.
 */
public final class PearlDeathListener implements Listener {

    private final JavaPlugin plugin;
    private final PlayerDataStore dataStore;
    private final PendingPearlStore pending;
    private final Messages messages;

    public PearlDeathListener(JavaPlugin plugin, PlayerDataStore dataStore,
                              PendingPearlStore pending, Messages messages) {
        this.plugin = plugin;
        this.dataStore = dataStore;
        this.pending = pending;
        this.messages = messages;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getPlayer();
        if (dataStore.getMode(player.getUniqueId()) != PearlMode.PERSISTENT) {
            return;
        }

        List<PearlSnapshot> captured = new ArrayList<>();
        for (World world : Bukkit.getWorlds()) {
            for (EnderPearl pearl : world.getEntitiesByClass(EnderPearl.class)) {
                if (pearl.getShooter() instanceof Player shooter
                        && shooter.getUniqueId().equals(player.getUniqueId())) {
                    captured.add(PearlSnapshot.capture(pearl));
                    pearl.remove();
                }
            }
        }
        if (!captured.isEmpty()) {
            pending.add(player.getUniqueId(), captured);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        scheduleRestore(event.getPlayer());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Covers players who logged out while dead and came back on the next session.
        scheduleRestore(event.getPlayer());
    }

    /** Runs one tick later so the player is fully placed before the pearls spawn. */
    private void scheduleRestore(Player player) {
        Bukkit.getScheduler().runTask(plugin, () -> restore(player));
    }

    private void restore(Player player) {
        List<PearlSnapshot> snapshots = pending.take(player.getUniqueId());
        if (snapshots.isEmpty()) {
            return;
        }
        if (!player.isOnline()) {
            pending.add(player.getUniqueId(), snapshots);
            return;
        }

        int count = 0;
        for (PearlSnapshot snapshot : snapshots) {
            Location location = snapshot.toLocation();
            if (location == null) {
                continue; // world no longer loaded; the pearl cannot be placed
            }
            location.getWorld().spawn(location, EnderPearl.class, pearl -> {
                pearl.setShooter(player);
                pearl.setVelocity(snapshot.velocity());
            });
            count++;
        }
        if (count > 0) {
            player.sendMessage(messages.restored(count));
        }
    }
}
